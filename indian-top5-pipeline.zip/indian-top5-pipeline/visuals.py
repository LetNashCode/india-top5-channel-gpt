"""
Fetches royalty-free stock video clips from Pexels matching each item's
visual_keywords. Falls back to a still-image Ken Burns clip if no video
match is found (handled in assemble.py).
"""
import os
import requests

PEXELS_SEARCH_URL = "https://api.pexels.com/videos/search"


def _pexels_headers():
    return {"Authorization": os.environ["PEXELS_API_KEY"]}


def find_video_clip(keywords: list, orientation: str = "portrait") -> str | None:
    """Search Pexels for a matching video, return the best-quality portrait
    video URL, or None if nothing suitable was found."""
    query = " ".join(keywords)
    params = {"query": query, "orientation": orientation, "per_page": 5}
    resp = requests.get(PEXELS_SEARCH_URL, headers=_pexels_headers(), params=params, timeout=20)
    resp.raise_for_status()
    data = resp.json()

    videos = data.get("videos", [])
    if not videos:
        return None

    video = videos[0]
    # Pick the highest-resolution file that's still reasonably sized
    files = sorted(video["video_files"], key=lambda f: f.get("height", 0), reverse=True)
    for f in files:
        if f.get("height", 0) <= 1920:
            return f["link"]
    return files[-1]["link"] if files else None


def download_file(url: str, out_path: str) -> str:
    resp = requests.get(url, stream=True, timeout=60)
    resp.raise_for_status()
    with open(out_path, "wb") as f:
        for chunk in resp.iter_content(chunk_size=1 << 20):
            f.write(chunk)
    return out_path


def fetch_visuals_for_script(script: dict, config: dict, workdir: str) -> list:
    """Returns a list of local file paths (video clips), one per item, in order.
    If a search comes up empty, returns None for that slot so assemble.py can
    fall back to a solid-color/text card instead of crashing the run."""
    os.makedirs(workdir, exist_ok=True)
    orientation = config["visuals"]["orientation"]
    clip_paths = []
    for item in script["items"]:
        url = find_video_clip(item["visual_keywords"], orientation)
        if url is None:
            clip_paths.append(None)
            continue
        out_path = os.path.join(workdir, f"visual_{item['rank']}.mp4")
        download_file(url, out_path)
        clip_paths.append(out_path)
    return clip_paths
